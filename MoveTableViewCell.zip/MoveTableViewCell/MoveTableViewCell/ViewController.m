//
//  ViewController.m
//  MoveTableViewCell
//
//  Created by Evan on 16/7/6.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "ViewController.h"
#import "UIAlertView+RWBlock.h"

static NSString * const MoveTableViewCellID = @"MoveTableViewCellID";

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, weak) UITableView *tableView;

@property (nonatomic , strong) NSMutableArray *objects;

@end

@implementation ViewController

#pragma mark - Data

- (NSMutableArray *)objects
{
    if (!_objects) {
        _objects = [NSMutableArray array];
    }
    return _objects;
}

#pragma mark - Control
- (UITableView *)tableView
{
    if (!_tableView)
    {
        UITableView *tableView = [[UITableView alloc] init];
        
        tableView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        tableView.rowHeight = 200.f;
        [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:MoveTableViewCellID];
        tableView.backgroundColor = [UIColor grayColor];
        
        self.tableView = tableView;
        [self.view addSubview:tableView];
    }
    return _tableView;
}

#pragma mark - LfileCycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"MoveTableViewCell";
    
    NSMutableArray *listTop = [[NSMutableArray alloc] initWithArray:@[@"推荐",@"热点",@"杭州",@"社会",@"娱乐",@"科技",@"汽车",@"体育",@"订阅",@"财经",@"军事",@"国际",@"正能量",@"段子",@"趣图",@"美女",@"健康",@"教育",@"特卖",@"彩票",@"辟谣"]];
    
    self.objects = listTop;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressGestureRecognized:)];
    [self.tableView addGestureRecognizer:longPress];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)];
}

#pragma mark - Touch Event
- (void)addButtonPressed:(id)sender
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Add a new to-do item:" message:nil delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:@"Add", nil];
    
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;// 有输入框格式
    
    __weak typeof(self) weakself = self;

    [alertView setCompletionBlock:^(UIAlertView *alertView, NSInteger buttonIndex) {
        
        // 添加
        if (buttonIndex == 1)
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            NSString *string = [textField.text capitalizedString];
            [weakself.objects addObject:string];
            
            NSUInteger row = [weakself.objects count] - 1;
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
            [weakself.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.view endEditing:YES];
        }
    }];

    [alertView show];
}

- (void)longPressGestureRecognized:(id)sender
{   // 手势
    UILongPressGestureRecognizer *longPress = (UILongPressGestureRecognizer *)sender;
    // 触摸事件
    UIGestureRecognizerState state = longPress.state;// 触摸事件
    
    // 获取触摸事件的位置
    CGPoint location = [longPress locationInView:self.tableView];
    
    // 获取位置当前的行
    NSIndexPath *indextPath = [self.tableView indexPathForRowAtPoint:location];
    
    // 行用户的快照正在移动View。
    static UIView *snapshot = nil;
    //初始索引路径，在那里手势开始。
    static NSIndexPath *sourceIndexPath = nil;

    switch (state)
    {
            // 长按状态
        case UIGestureRecognizerStateBegan:
        {
            if (indextPath)
            {
                sourceIndexPath = indextPath;
                UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indextPath];
                
                snapshot = [self customSnapshoFromView:cell];
                
                __block CGPoint center = cell.center;
                snapshot.center = center;
                snapshot.alpha = 0.0;
                [self.tableView addSubview:snapshot];
                
                [UIView animateWithDuration:0.5 animations:^{
                   
                    center.y = location.y;
                    snapshot.transform = CGAffineTransformMakeScale(1.05, 1.05);
                    snapshot.alpha = 0.98;
                    cell.alpha = 0;
                    cell.hidden = YES;
                }];
                
            }
        }
            // 移动状态
            case UIGestureRecognizerStateChanged:
        {
            CGPoint center = snapshot.center;
            center.y = location.y;
            snapshot.center = center;
            
            if (indextPath && ![indextPath isEqual:sourceIndexPath])
            {
                // 交换对象索引
                [self.objects exchangeObjectAtIndex:indextPath.row withObjectAtIndex:sourceIndexPath.row];
                
                // 移动tableiewCell
                [self.tableView moveRowAtIndexPath:sourceIndexPath toIndexPath:indextPath];
                sourceIndexPath = indextPath;
            }
        }
            break;
            
        default:
        {
            // Clean up.
            UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indextPath];
            cell.alpha = 0.0;
            
            [UIView animateWithDuration:0.5 animations:^{
                
                snapshot.center = cell.center;
                snapshot.transform = CGAffineTransformIdentity;
                snapshot.alpha = 0.0;
                cell.alpha = 1.0;
            } completion:^(BOOL finished) {
               
                cell.hidden = NO;
                sourceIndexPath = nil;
                [snapshot removeFromSuperview];
                snapshot = nil;
            }];
        }
            break;
    }
}

#pragma mark - Layout
// 长按时候出现Cell效果
- (UIView *)customSnapshoFromView:(UIView *)inputView {
    
    // 用户界面图形开始图像上下文与选项
    UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, NO, 0);
    [inputView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    UIView *snapshot = [[UIImageView alloc] initWithImage:image];
    snapshot.layer.masksToBounds = NO;
    snapshot.layer.cornerRadius = 0.0;
    snapshot.layer.shadowOffset = CGSizeMake(-5.0, 0.0);
    snapshot.layer.shadowRadius = 5.0;
    snapshot.layer.shadowOpacity = 0.4;
    
    return snapshot;
}

#pragma mark - UItableView Dategate && DataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _objects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MoveTableViewCellID forIndexPath:indexPath];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = _objects[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    /**< 这里会告诉你删除第几行，然后删除，刷新 */
    [self.objects removeObjectAtIndex:indexPath.row];

    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
        CATransform3D transform = CATransform3DMakeScale(0.5, 0.5, 1.0);
        cell.layer.transform = transform;
        
        [UIView beginAnimations:@"transform" context:NULL];
        [UIView setAnimationDuration:0.5];
        cell.layer.transform = CATransform3DIdentity;
        cell.alpha = 1.0;
        cell.layer.shadowOffset = CGSizeMake(0, 0);// 回到原点
        [UIView commitAnimations];
}

@end
